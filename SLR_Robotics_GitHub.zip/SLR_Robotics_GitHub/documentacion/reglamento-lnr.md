# Referencia reglamentaria — LNR

Consultar siempre la versión vigente en el sitio oficial:

- https://www.lnr-argentina.com.ar/
- https://lnr-argentina.com.ar/categorias/carrera
- https://lnr-argentina.com.ar/reglamentos/Reglamento%20Carrera.pdf

La modalidad Carrera y Carrera Pro se diferencian principalmente por el uso de sistemas de impulsión como turbinas/aspas. Revisar el PDF vigente para confirmar medidas, homologación, seguridad y condiciones de competencia antes de cada evento.
