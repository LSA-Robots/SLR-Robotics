# Seguidor de línea — Arduino Nano

## Descripción
Robot autónomo que detecta una línea mediante sensores reflectivos y ajusta sus motores para seguir el recorrido.

## Fotografías
Subí las imágenes a `fotos/` y agregalas aquí, por ejemplo:

`![Vista superior](fotos/vista-superior.jpg)`

## Componentes
- Arduino Nano
- Arreglo QTR de 8 sensores (versión documentada)
- Driver TB6612FNG
- 2 motores N20
- Batería de dos celdas de litio
- Pulsador y LED indicador

## Funcionamiento
El programa calibra los sensores, calcula la posición de la línea y aplica correcciones mediante control PID para ajustar la velocidad de cada motor.

## Código
Guardá el sketch `.ino` correspondiente dentro de `codigo/`. Indicá aquí la versión, fecha y cambios importantes.

## Datos técnicos por completar
- Dimensiones reales:
- Peso:
- Tensión de batería:
- Velocidad / pruebas:
- Estado de homologación LNR:
