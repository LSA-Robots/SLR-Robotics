# Seguidor de línea — ESP32-S3

## Descripción
Prototipo de seguidor de línea con ESP32-S3 y lectura multiplexada de 16 sensores.

## Fotografías
Subí las imágenes a `fotos/` y agregalas aquí:

`![Vista superior](fotos/vista-superior.jpg)`

## Componentes documentados / previstos
- ESP32-S3
- 16 sensores de línea con multiplexación
- Drivers RZ7889
- Dos motores DC
- Pulsador
- Señal Micro Start, según el montaje
- Batería y alimentación de motores

## Conexiones
Completá esta sección con el pinout final verificado antes de publicar el proyecto.

## Código
Guardá el programa `.ino` probado dentro de `codigo/`.

## Estado y pruebas
- Estado actual:
- Lectura de sensores:
- Prueba de motores:
- Prueba de seguimiento:
- Pendientes:
