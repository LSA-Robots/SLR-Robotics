# Nombre del robot

## Descripción breve
¿Qué hace el robot y cuál es su objetivo?

## Fotografías
Agregá las imágenes en `fotos/` y enlazalas aquí:
`![Vista del robot](fotos/robot.jpg)`

## Componentes
| Componente | Modelo | Función |
|---|---|---|
| Microcontrolador | | |
| Sensores | | |
| Driver | | |
| Motores | | |
| Batería | | |
| Otros | | |

## Conexiones
| Pin del controlador | Componente | Señal |
|---|---|---|
| | | |

## Funcionamiento
Explicá cómo detecta el entorno, toma decisiones y se mueve.

## Código
Guardá el código fuente en `codigo/`. Explicá qué archivo es el principal y qué librerías necesita.

## Datos técnicos
- Dimensiones:
- Peso:
- Alimentación:
- Categoría:
- Estado del proyecto:

## Pruebas y mejoras
- Pruebas realizadas:
- Problemas encontrados:
- Mejoras futuras:
