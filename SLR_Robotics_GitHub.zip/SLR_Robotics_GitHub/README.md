<div align="center">

<img src="assets/slr-robotics-logo.png" alt="SLR Robotics logo" width="420">

# SLR ROBOTICS
### Santiago Lacoste | Robotics & Engineering

**Diseño · Electrónica · Programación · Robótica móvil**

[Proyectos](#-proyectos) · [Disciplinas](#-disciplinas) · [Tecnologías](#-tecnologías) · [Contacto](#-contacto)

</div>

---

## 👋 Sobre mí

¡Hola! Soy **Santiago Lacoste**, estudiante y entusiasta de la robótica, la electrónica y la programación.

A través de **SLR Robotics** comparto los robots que diseño, construyo, programo y mejoro. Me interesa especialmente la robótica móvil, el desarrollo de robots autónomos y la experimentación con sensores, microcontroladores, motores y sistemas de control.

En este espacio documento el proceso completo de cada proyecto: desde la idea y el diseño electrónico hasta las pruebas, los ajustes y el código utilizado.

## 🤖 Disciplinas

### Seguidor de línea

Un robot seguidor de línea es un vehículo autónomo que utiliza sensores ópticos o infrarrojos para detectar una trayectoria marcada sobre una superficie. El controlador interpreta las lecturas de los sensores y modifica la velocidad de los motores para mantener el robot sobre el recorrido.

En mis proyectos trabajo con lectura de sensores, calibración, control de motores y algoritmos de corrección. También experimento con control PID para mejorar la estabilidad, la precisión y la velocidad en curvas y rectas.

### Carrera — Liga Nacional de Robótica

En la modalidad **Carrera** de la Liga Nacional de Robótica, dos robots seguidores de línea compiten sobre circuitos equivalentes. El objetivo es completar el recorrido antes que el rival.

De acuerdo con el reglamento de Carrera consultado:
- El robot debe funcionar de forma autónoma durante la prueba.
- Sus dimensiones máximas son **20 cm de largo × 14 cm de ancho × 10 cm de alto**.
- Debe contar con un indicador luminoso que señale el inicio de la rutina.
- La propulsión se realiza mediante motores, motorreductores eléctricos o servos alimentados por baterías.
- No se permite utilizar turbinas, palas u otros sistemas de empuje o succión en la categoría Carrera.
- Una vez iniciada la prueba, no se puede controlar directamente el robot; la orden remota permitida es detenerlo.

### Carrera Pro — Liga Nacional de Robótica

Carrera Pro comparte el objetivo de competir siguiendo un circuito, pero permite el uso de sistemas de impulsión mediante turbina o aspas, sujetos a las condiciones del reglamento.

**Importante:** las condiciones técnicas y de homologación pueden actualizarse. Antes de competir hay que revisar el reglamento vigente publicado por la LNR y comprobar que cada robot cumpla sus medidas y requisitos.

## 🏁 Proyectos

Cada robot tiene su propia carpeta con fotografías, descripción, componentes y código fuente.

### 01 — Seguidor de línea | Arduino Nano

**Estado:** proyecto desarrollado / sujeto a las versiones documentadas en esta carpeta.

Robot móvil basado en Arduino Nano, sensores reflectivos QTR y control de dos motores N20. El movimiento se gestiona mediante un driver TB6612FNG. El programa utiliza una lógica de seguimiento con control PID y rutinas de calibración y arranque.

**Componentes documentados:**
- Arduino Nano.
- Sensores QTR (arreglo de 8 sensores en la versión documentada).
- Driver doble puente H TB6612FNG.
- 2 motoresreductores N20.
- Batería de dos celdas de litio.
- Pulsador de control y LED indicador.

**Fotografías:** ver `robots/seguidor-linea-arduino-nano/fotos/`.

**Código:** ver `robots/seguidor-linea-arduino-nano/codigo/`.

### 02 — Seguidor de línea | ESP32-S3

**Estado:** prototipo / desarrollo.

Nueva plataforma de seguimiento de línea basada en ESP32-S3, con arreglo de 16 sensores multiplexados y módulos controladores de motores RZ7889. Este proyecto busca trasladar y adaptar la lógica de seguimiento a un hardware diferente.

**Componentes previstos/documentados:**
- ESP32-S3.
- 16 sensores de lectura de línea con multiplexación.
- Módulos drivers RZ7889.
- Dos motores de corriente continua.
- Pulsador de control.
- Señal de Micro Start, según el montaje utilizado.
- Alimentación para lógica y motores.

**Nota:** la asignación de pines, el cableado final y el programa deben completarse con la versión efectivamente probada del prototipo.

**Fotografías:** ver `robots/seguidor-linea-esp32s3/fotos/`.

**Código:** ver `robots/seguidor-linea-esp32s3/codigo/`.

## 🧰 Tecnologías

- **Microcontroladores:** Arduino Nano, Arduino UNO, ESP32 y ESP32-S3.
- **Programación:** C/C++ para Arduino.
- **Sensores:** sensores reflectivos e infrarrojos.
- **Control de movimiento:** PWM, puentes H y control PID.
- **Electrónica:** alimentación, cableado, drivers y montaje de circuitos.

## 📂 Cómo está organizado este repositorio

```text
SLR_Robotics_GitHub/
├── README.md
├── assets/
│   └── slr-robotics-logo.png
├── robots/
│   ├── seguidor-linea-arduino-nano/
│   │   ├── README.md
│   │   ├── fotos/
│   │   └── codigo/
│   └── seguidor-linea-esp32s3/
│       ├── README.md
│       ├── fotos/
│       └── codigo/
├── plantilla-nuevo-robot/
│   ├── README.md
│   ├── fotos/
│   └── codigo/
└── documentacion/
    └── reglamento-lnr.md
```

## 📚 Referencias

- [Liga Nacional de Robótica — sitio oficial](https://www.lnr-argentina.com.ar/)
- [Categoría Carrera — LNR](https://lnr-argentina.com.ar/categorias/carrera)
- [Reglamento de Carreras — PDF](https://lnr-argentina.com.ar/reglamentos/Reglamento%20Carrera.pdf)

La información reglamentaria de este README es una síntesis orientativa. El reglamento oficial vigente prevalece ante cualquier diferencia.

## 📬 Contacto

**Santiago Lacoste**  
**SLR Robotics**

Este repositorio reúne proyectos personales de aprendizaje, experimentación y desarrollo en robótica.
